function mdisplay(m)
	image(255* abs(m) / max(max(abs(m))));
