^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package laser_ortho_projector
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2016-03-19)
------------------

0.3.1 (2015-12-18)
------------------

0.3.0 (2015-11-10)
------------------

0.2.1 (2015-10-14)
------------------
* [feat] added support for IMU message for orientation in laser_ortho_projector. The imu topic is imu/data
* [fix] PCL dependency Hydro onward
* [sys] Catkinization: laser_ortho_projector
* Contributors: Ivan Dryanovski, Miguel Sarabia, Enrique Fernández Perdomo
