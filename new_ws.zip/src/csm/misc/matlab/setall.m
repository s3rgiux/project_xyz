
path(path,genpath(pwd));
