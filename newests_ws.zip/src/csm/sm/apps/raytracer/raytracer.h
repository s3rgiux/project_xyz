
#ifndef H_RAYTRACER
#define H_RAYTRACER


#include <json-c/json.h>

#include "simplemap.h"
using namespace RayTracer;

#include <csm/csm_all.h>
using namespace CSM;

#include <options/options.h>


#endif

