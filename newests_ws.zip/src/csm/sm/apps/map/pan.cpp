#include "pan.h"

LDP pan_new(int nrays) {
	
}

void pan_merge(LDP pan, LDP ld) {
	
}

