^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package polar_scan_matcher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2016-03-19)
------------------

0.3.1 (2015-12-18)
------------------

0.3.0 (2015-11-10)
------------------

0.2.1 (2015-10-14)
------------------
* [feat] added polar scan matcher
* [feat] added imu option to PSM, made CSM and PSM look similar
* [feat] added demo dir to CSM, 
* [fix] PSM launch file
* [sys] ROS Hydro compatible
* [sys] Cleaning
* [sys] correct license and references to PSM and CSM
* Contributors: Daniel Axtens, Ivan Dryanovski
